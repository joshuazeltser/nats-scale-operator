package no_test_fn

func StringIdentity(a string) string {
	return a
}
