package filter_fixture_test

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("SprocketB", func() {
	It("cat", func() {

	})

	It("dog", func() {

	})

	It("cat fish", func() {

	})

	It("dog fish", func() {

	})

	It("fish", Label("slow"), func() {

	})
})
