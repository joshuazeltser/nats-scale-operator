package types

const VERSION = "2.22.0"
