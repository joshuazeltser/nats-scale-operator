package nonginkgo_sub_package_test

import "testing"

func TestA(t *testing.T) {

}
