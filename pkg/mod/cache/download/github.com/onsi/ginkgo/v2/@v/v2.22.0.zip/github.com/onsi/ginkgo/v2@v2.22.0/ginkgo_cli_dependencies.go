//go:build ginkgoclidependencies
// +build ginkgoclidependencies

package ginkgo

import (
	_ "github.com/onsi/ginkgo/v2/ginkgo"
)
